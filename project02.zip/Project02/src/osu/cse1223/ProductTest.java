/**
 * ProductTest
 * 
 *   Test the product class
 *   
 *   @author Tyler Zysberg
 *   @version 20160918
 */

package osu.cse1223;

public class ProductTest {

	public static void main(String[] args) {
		Product p1 = new Product();
		p1.setName("Anything");
		p1.setInventoryCode("C0000001");
		p1.setQuantity(50);
		p1.setPrice(39.99);
		p1.setType("CD");
		p1.addUserRating(3);
		
		System.out.println(p1.getName());
		System.out.println(p1.getInventoryCode());
		System.out.println(p1.getQuantity());
		System.out.println(p1.getPrice());
		System.out.println(p1.getType());
		System.out.println(p1.getAvgUserRating());
		System.out.println(p1.getUserRatingCount());
		System.out.println("-1");
	}

}
