package osu.cse1223;

import java.util.ArrayList;

/**
 * Product
 * 
 *   A simple class framework used to demonstrate the design
 *   of Java classes.
 *   
 *   @author Tyler Zysberg
 *   @version 20160918
 */

public class Product {
	
	// Private member variables go here - you will need to add them yourself.
	private String name;
	private int quantity;
	private double price;
	private String type;
	private String itemCode;
	private ArrayList <Integer> userrating;
	/*
	 * Product constructor
	 */
	public Product() {
		name = "";
		quantity = 0;
		price = 0;
		type = "";
		itemCode = "";
		userrating = new ArrayList<Integer>();
	}
	
	public Product(String name, int quantity, double price, String type, String itemcode, ArrayList<Integer> userranking){
		  this.name = name;
		  this.quantity = quantity;
		  this.price = price;
		  this.type = type;
		  this.itemCode = itemcode;
		  this.userrating = new ArrayList<Integer>();
		}

	/*
	 * setName
	 *  @param name - new name for the product
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	/*
	 * getName
	 *  @return the name of the product
	 */
	public String getName() {
		return name;
	}
	
	/*
	 * setType
	 *  @param type - the type of the product
	 */
	public void setType(String type) {
		this.type = type;
	}
	
	/*
	 * getType
	 * @return - the product type
	 */
	public String getType() {
		return type;
	}
	
	/*
	 * setPrice
	 * @param price - the price of the product
	 */
	public void setPrice(double price) {
		this.price = price;
	}
	
	/*
	 * getPrice
	 * @return the price of the product
	 */
	public double getPrice() {
		return price;
	}
	
	/*
	 * setQuantity
	 * @param quantity - the number of this product in inventory
	 */
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	/*
	 * getQuantity
	 * @return the number of this product in inventory
	 */
	public int getQuantity() {
		return quantity;
	}
	
	/*
	 * setInventoryCode
	 * @param code - the new inventory code for the product
	 */
	public void setInventoryCode(String code) {
		this.itemCode = code;
	}
	
	/*
	 * getInventoryCode
	 * @return the inventory code of the product
	 */
	public String getInventoryCode() {
		return itemCode;
	}
	
	/*
	 * addUserRating
	 * NOTE: Each individual rating is stored with the product, so you need to maintain a list
	 * of user ratings.  This method should append a new rating to the end of that list
	 * @param rating - the new rating to add to this product
	 */
	public void addUserRating(int rating) {
		if(rating >= 0 && rating <= 5){
			userrating.add(rating);
		}
	}
	
	/*
	 * getUserRating
	 * 	NOTE:  See note on addUserRating above.  This method should be written to allow you
	 * 	to access an individual value from the list of user ratings 
	 * @param index - the index of the rating we want to see
	 * @return the rating indexed by the value index
	 */
	public int getUserRating(int index) {
		return userrating.get(index);
	}
	
	/*
	 * getUserRatingCount
	 *  NOTE: See note on addUserRating above.  This method should be written to return
	 *  the total number of ratings this product has associated with it
	 * @return the number of ratings associated with this product
	 */
	public int getUserRatingCount() {
		return userrating.size();
	}
	
	/*
	 * getAvgUserRating
	 *  NOTE: see note on addUserRating above.  This method should be written to compute
	 *  the average user rating on demand from a stored list of ratings.
	 * @return the average rating for this product as a whole integer value (use integer math)
	 */
	public int getAvgUserRating() {
		 int average = 0;
		 int sum = 0;
		  for (int index=0; index < userrating.size();index++) {
		   sum = userrating.get(index) + sum;
		  }
		  if (userrating.size() != 0){
		  average = sum / userrating.size();
		  }
		  else{
		   average = 0;
		  }
		  return average;
	}
}
