/**
 * Product
 * 
 *   A simple class framework used to demonstrate the design
 *   of Java classes.
 *   
 *   @author Tyler Zysberg
 *   @version 20160918
 */
package osu.cse1223;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import osu.cse1223.Product;

public class Project02 {

	private static Scanner in;
	public static void main(String[] args) throws FileNotFoundException {
		in = new Scanner(System.in);
		System.out.print("Enter an inventory filename:");
		String input = in.nextLine();
		ArrayList<Product> products = loadProduct(input);
		outPut(products);

	}
	public static ArrayList<Product> loadProduct(String input){
		  try{
			   ArrayList <Product> productInfo = new ArrayList<Product>();
			   ArrayList <Integer> rating = new ArrayList<Integer>();
			   Scanner inFile = new Scanner (new File (input));
			   while (inFile.hasNext()){
			    String name =inFile.nextLine();
			    String code =inFile.nextLine();
			    int quantity = inFile.nextInt();
			    double price =inFile.nextDouble();
			    inFile.nextLine();
			    String type = inFile.nextLine();
			    int rate = inFile.nextInt();
			    Product p1 = new Product(name,quantity,price,type,code,rating);
			    while (rate != -1){
			    rating.add(rate);
			    p1.addUserRating(rate);
			     rate = inFile.nextInt();
			     inFile.nextLine();
			    }
			    productInfo.add(p1);
			   }
			   
			   inFile.close();
			   return productInfo;
			  }

			catch (IOException e) {
			  System.out.println("There is an error!");
			}
			  return null;
	
	}
	private static void outPut(ArrayList<Product> products) {
		  String name ="Product Name";
		  String code = "I Code";
		  String type = "Type";
		  String rating = "Rating";
		  String count = "# Rat.";
		  String quantity = "Quant.";
		  String price = "Price";
		  System.out.println("Product Inventory Summary Report");
		  System.out.println("----------------------------------------------------------------------------------");
		  System.out.println("");
		  System.out.format("%-35s %-9s %-5s %-2s %-2s %-2s %-2s %n",name,code,type,rating,count,quantity,price);
		  System.out.println("----------------------------------------------------------------------------------");
		  for(int i=0;i<products.size();i++){
		   Product display = products.get(i);
		   String star = "******";
		   int r1 = display.getAvgUserRating();
		   star = star.substring(0,r1);
		   System.out.format("%-35s %-9s %-5s %-10s %-3s %-5d %-2.2f %n",display.getName(),display.getInventoryCode(),display.getType(),star,display.getUserRatingCount(),display.getQuantity(),display.getPrice());
		  }
		   System.out.println("----------------------------------------------------------------------------------");
		   System.out.println("Total products in database: "+ products.size());
		   outputHighest(products);
		   outputLowest(products);
		   outputHighestDollar(products);
		   outputLowestDollar(products);
		   System.out.println("----------------------------------------------------------------------------------"); 
			}
	
	private static void outputLowestDollar(ArrayList<Product> products) {
		  double min=0;
		  String name = "";
		  Product product = products.get(0);
		  min = product.getPrice()*product.getQuantity();
		  for (int index = 1; index < products.size();index++){
		  product = products.get(index);
		  if (min >= product.getPrice()*product.getQuantity()){
		   min = product.getPrice()*product.getQuantity();
		   name = product.getName();
		  	}
		  }
		  System.out.format("Highest Total Dollar item: %s ( $%-,5.2f ) %n",name,min);
		
	}
	private static void outputHighestDollar(ArrayList<Product> products) {
		  double max=0;
		  String name = "";
		  Product product = products.get(0);
		  max = product.getPrice()*product.getQuantity();
		  for (int index = 1; index < products.size();index++){
		  product = products.get(index);
		  if (max <= product.getPrice()*product.getQuantity()){
		   max = product.getPrice()*product.getQuantity();
		   name = product.getName();
		  	}
		  }
		  System.out.format("Highest Total Dollar item: %s ( $%-,5.2f ) %n",name,max);
		
	}
	private static void outputLowest(ArrayList<Product> products) {
		 int min=0;
		  String name = "";
		  String star = "*****";
		  String rate = "";
		  Product product = products.get(0);
		  min = product.getAvgUserRating();
		  for (int index = 1; index < products.size();index++){
		  product = products.get(index);
		  if (min >= product.getAvgUserRating()){
		   min = product.getAvgUserRating();
		   name = product.getName();
		  }
		  rate = star.substring(0,min);
		 }
		  System.out.println("Highest Average Rating item: "+name +" ("+ rate+")");
		
	}
	private static void outputHighest(ArrayList<Product> products) {
		  int max=0;
		  String name = "";
		  String star = "*****";
		  String rate = "";
		  Product product = products.get(0);
		  max = product.getAvgUserRating();
		  for (int index = 1; index < products.size();index++){
		  product = products.get(index);
		  if (max <= product.getAvgUserRating()){
		   max = product.getAvgUserRating();
		   name = product.getName();
		  }
		  rate = star.substring(0,max);
		  }
		  System.out.println("Highest Average Rating item: "+ name +" ("+ rate+")");
		
	}

}
